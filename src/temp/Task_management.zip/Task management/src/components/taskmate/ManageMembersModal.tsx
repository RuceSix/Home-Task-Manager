import { useState, useEffect } from 'react';
import { X, UserPlus, Trash2, Mail } from 'lucide-react';
import { House, HouseMember, HouseInvitation } from '@/types/taskmate';

interface ManageMembersModalProps {
  isOpen: boolean;
  onClose: () => void;
  houses: House[];
  currentHouse: House | null;
  currentUserId: string;
  onLoadHouseMembers: (houseId: string) => Promise<{ members: HouseMember[]; invitations: HouseInvitation[] }>;
  onInviteMember: (houseId: string, email: string) => Promise<void>;
  onRemoveMember: (houseId: string, memberId: string) => Promise<void>;
  onCancelInvitation: (invitationId: string) => Promise<void>;
}

export function ManageMembersModal({
  isOpen,
  onClose,
  houses,
  currentHouse,
  currentUserId,
  onLoadHouseMembers,
  onInviteMember,
  onRemoveMember,
  onCancelInvitation
}: ManageMembersModalProps) {
  const [selectedHouse, setSelectedHouse] = useState<House | null>(null);
  const [members, setMembers] = useState<HouseMember[]>([]);
  const [invitations, setInvitations] = useState<HouseInvitation[]>([]);
  
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Initialize with current house when modal opens
  useEffect(() => {
    if (isOpen && currentHouse && !selectedHouse) {
      setSelectedHouse(currentHouse);
    }
  }, [isOpen, currentHouse, selectedHouse]);

  // Load members when house changes
  useEffect(() => {
    const loadMembers = async () => {
      if (!selectedHouse) return;
      
      try {
        const data = await onLoadHouseMembers(selectedHouse.id);
        setMembers(data.members);
        setInvitations(data.invitations);
      } catch (err) {
        console.error('Error loading members:', err);
      }
    };

    if (selectedHouse) {
      loadMembers();
    }
  }, [selectedHouse, onLoadHouseMembers]);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setSelectedHouse(null);
      setMembers([]);
      setInvitations([]);
      setEmail('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isOwner = selectedHouse?.ownerId === currentUserId;
  const pendingInvitations = invitations.filter(inv => inv.status === 'pending');

  const handleInvite = async () => {
    if (!email.trim() || !selectedHouse) return;
    
    setIsLoading(true);
    try {
      await onInviteMember(selectedHouse.id, email.trim());
      setEmail('');
      alert(`Invito inviato a ${email.trim()}!`);
      
      // Reload members to get updated invitations
      const data = await onLoadHouseMembers(selectedHouse.id);
      setMembers(data.members);
      setInvitations(data.invitations);
    } catch (err) {
      alert('Errore durante l\'invio dell\'invito');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemove = async (memberId: string) => {
    if (!selectedHouse) return;
    
    try {
      await onRemoveMember(selectedHouse.id, memberId);
      setMembers(members.filter(m => m.id !== memberId));
    } catch (err) {
      alert('Errore durante la rimozione');
    }
  };

  const handleCancelInvitation = async (invitationId: string) => {
    try {
      await onCancelInvitation(invitationId);
      setInvitations(invitations.filter(i => i.id !== invitationId));
    } catch (err) {
      alert('Errore durante l\'annullamento');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-bold text-foreground">Gestisci Membri</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-2">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {/* Invite Section */}
          {isOwner && (
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-foreground mb-3">Invita Membro</h3>
              <div className="flex gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleInvite()}
                  placeholder="Email..."
                  className="flex-1 px-4 py-3 border border-border rounded-lg bg-background text-foreground focus:ring-2 focus:ring-primary focus:outline-none"
                />
                <button 
                  onClick={handleInvite}
                  disabled={isLoading}
                  className="bg-primary text-primary-foreground px-4 py-3 rounded-lg hover:bg-primary/90 flex items-center gap-2 font-medium disabled:opacity-50"
                >
                  <Mail size={18} />
                  Invita
                </button>
              </div>
            </div>
          )}

          {/* Members List */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-foreground mb-3">Membri ({members.length})</h3>
            <div className="space-y-2">
              {members.map(member => {
                const displayName = member.userName || member.userEmail || 'Utente';
                return (
                  <div key={member.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                        <span className="text-primary font-semibold">
                          {displayName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{displayName}</p>
                        <p className="text-xs text-muted-foreground">
                          {member.role === 'owner' ? 'Proprietario' : 'Membro'}
                        </p>
                      </div>
                    </div>
                    {isOwner && member.role !== 'owner' && (
                      <button 
                        onClick={() => handleRemove(member.id)} 
                        className="text-destructive p-2 hover:bg-destructive/10 rounded-lg"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Invitations List */}
          {pendingInvitations.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">Inviti ({pendingInvitations.length})</h3>
              <div className="space-y-2">
                {pendingInvitations.map(inv => (
                  <div key={inv.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-xl">
                    <div>
                      <p className="font-medium text-foreground">{inv.invitedEmail}</p>
                      <p className="text-xs text-muted-foreground">In attesa</p>
                    </div>
                    {isOwner && (
                      <button 
                        onClick={() => handleCancelInvitation(inv.id)} 
                        className="text-destructive p-2 hover:bg-destructive/10 rounded-lg"
                      >
                        <X size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
