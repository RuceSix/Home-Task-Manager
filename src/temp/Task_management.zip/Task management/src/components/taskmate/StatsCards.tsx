import { Task, ShoppingItem } from '@/types/taskmate';

interface StatsCardsProps {
  tasks: Task[];
  shopping: ShoppingItem[];
}

export function StatsCards({ tasks, shopping }: StatsCardsProps) {
  const openTasks = tasks.filter(t => !t.completed).length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const totalItems = shopping.length;

  return (
    <div className="grid grid-cols-3 gap-4 animate-slide-up">
      <div className="stat-card">
        <p className="text-2xl md:text-3xl font-bold text-primary">{openTasks}</p>
        <p className="text-xs md:text-sm text-muted-foreground">Compiti aperti</p>
      </div>
      <div className="stat-card">
        <p className="text-2xl md:text-3xl font-bold text-success">{completedTasks}</p>
        <p className="text-xs md:text-sm text-muted-foreground">Completati</p>
      </div>
      <div className="stat-card">
        <p className="text-2xl md:text-3xl font-bold text-accent">{totalItems}</p>
        <p className="text-xs md:text-sm text-muted-foreground">Articoli spesa</p>
      </div>
    </div>
  );
}
