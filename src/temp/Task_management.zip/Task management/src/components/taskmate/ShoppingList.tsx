import { useState } from 'react';
import { ShoppingCart, Plus, Trash2, Check, User } from 'lucide-react';
import { ShoppingItem } from '@/types/taskmate';

interface ShoppingListProps {
  items: ShoppingItem[];
  onAddItem: (item: string) => void;
  onToggleItem: (id: number) => void;
  onDeleteItem: (id: number) => void;
}

export function ShoppingList({ items, onAddItem, onToggleItem, onDeleteItem }: ShoppingListProps) {
  const [newItem, setNewItem] = useState('');

  const handleAdd = () => {
    if (newItem.trim()) {
      onAddItem(newItem.trim());
      setNewItem('');
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Add Item Input */}
      <div className="flex gap-2 mb-6">
        <input
          type="text"
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
          placeholder="Aggiungi articolo alla lista..."
          className="input-styled flex-1"
        />
        <button
          onClick={handleAdd}
          className="btn-primary px-4 md:px-6 py-3 flex items-center gap-2"
        >
          <Plus size={20} />
          <span className="hidden md:inline">Aggiungi</span>
        </button>
      </div>

      {/* Shopping List */}
      <div className="space-y-3">
        {items.map((item, index) => (
          <div
            key={item.id}
            className={`task-item ${item.checked ? 'task-item-completed' : 'task-item-pending'} animate-slide-up`}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <button
                onClick={() => onToggleItem(item.id)}
                className={`w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all duration-200 flex-shrink-0 ${
                  item.checked 
                    ? 'bg-success border-success' 
                    : 'border-muted-foreground/40 hover:border-primary hover:bg-primary/10'
                }`}
              >
                {item.checked && <Check size={14} className="text-success-foreground" />}
              </button>

              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate ${
                  item.checked 
                    ? 'line-through text-muted-foreground' 
                    : 'text-foreground'
                }`}>
                  {item.item}
                </p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-sm text-muted-foreground">
                  <span>Quantità: {item.quantity}</span>
                  {item.addedBy && (
                    <span className="flex items-center gap-1">
                      <User size={12} />
                      {item.addedBy}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={() => onDeleteItem(item.id)}
              className="text-destructive hover:text-destructive/80 p-2 rounded-lg hover:bg-destructive/10 transition-colors flex-shrink-0"
            >
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {items.length === 0 && (
        <div className="text-center py-12 text-muted-foreground animate-fade-in">
          <ShoppingCart size={48} className="mx-auto mb-3 opacity-50" />
          <p className="font-medium">Lista spesa vuota</p>
          <p className="text-sm">Aggiungi articoli!</p>
        </div>
      )}
    </div>
  );
}
