import { useState } from 'react';
import { CheckSquare, Plus, Trash2, Check, Users, Calendar } from 'lucide-react';
import { Task, HouseMember } from '@/types/taskmate';
import { AssigneeSelector } from './AssigneeSelector';

interface TaskListProps {
  tasks: Task[];
  members: HouseMember[];
  currentUserId: string;
  currentUserName: string;
  onAddTask: (title: string, assigneeId: string, assigneeName: string) => void;
  onToggleTask: (id: number) => void;
  onDeleteTask: (id: number) => void;
}

export function TaskList({ 
  tasks, 
  members,
  currentUserId,
  currentUserName,
  onAddTask, 
  onToggleTask, 
  onDeleteTask 
}: TaskListProps) {
  const [newTask, setNewTask] = useState('');
  const [selectedAssigneeId, setSelectedAssigneeId] = useState(currentUserId);
  const [selectedAssigneeName, setSelectedAssigneeName] = useState(currentUserName);

  const handleAdd = () => {
    if (newTask.trim()) {
      onAddTask(newTask.trim(), selectedAssigneeId, selectedAssigneeName);
      setNewTask('');
    }
  };

  const handleAssigneeChange = (memberId: string, memberName: string) => {
    setSelectedAssigneeId(memberId);
    setSelectedAssigneeName(memberName);
  };

  return (
    <div className="animate-fade-in">
      {/* Add Task Input */}
      <div className="flex flex-col gap-3 mb-6">
        <div className="flex gap-2">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
            placeholder="Aggiungi un nuovo compito..."
            className="input-styled flex-1"
          />
          <button
            onClick={handleAdd}
            className="btn-primary px-4 md:px-6 py-3 flex items-center gap-2"
          >
            <Plus size={20} />
            <span className="hidden md:inline">Aggiungi</span>
          </button>
        </div>
        {members.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Assegna a:</span>
            <AssigneeSelector
              members={members}
              selectedMemberId={selectedAssigneeId}
              onSelect={handleAssigneeChange}
            />
          </div>
        )}
      </div>

      {/* Task List */}
      <div className="space-y-3">
        {tasks.map((task, index) => (
          <div
            key={task.id}
            className={`task-item ${task.completed ? 'task-item-completed' : 'task-item-pending'} animate-slide-up`}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <button
                onClick={() => onToggleTask(task.id)}
                className={`checkbox-circle flex-shrink-0 ${
                  task.completed ? 'checkbox-checked' : 'checkbox-unchecked'
                }`}
              >
                {task.completed && <Check size={14} className="text-success-foreground" />}
              </button>

              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate ${
                  task.completed 
                    ? 'line-through text-muted-foreground' 
                    : 'text-foreground'
                }`}>
                  {task.title}
                </p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Users size={14} />
                    {task.assignee}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar size={14} />
                    {new Date(task.dueDate).toLocaleDateString('it-IT')}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onDeleteTask(task.id)}
              className="text-destructive hover:text-destructive/80 p-2 rounded-lg hover:bg-destructive/10 transition-colors flex-shrink-0"
            >
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {tasks.length === 0 && (
        <div className="text-center py-12 text-muted-foreground animate-fade-in">
          <CheckSquare size={48} className="mx-auto mb-3 opacity-50" />
          <p className="font-medium">Nessun compito</p>
          <p className="text-sm">Aggiungi il primo compito!</p>
        </div>
      )}
    </div>
  );
}
