import { Outlet, Navigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { useAuthStore } from "@/store/authStore";

export default function Layout() {
  const user = useAuthStore((s) => s.user);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}
