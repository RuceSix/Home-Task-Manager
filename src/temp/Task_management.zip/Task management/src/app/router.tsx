import { createBrowserRouter } from "react-router-dom";
import Layout from "@/app/layout";

import Home from "@/pages/Home";
import Devices from "@/pages/Devices";
import Automations from "@/pages/Automations";
import Settings from "@/pages/Settings";
import Login from "@/pages/Login";

export const router = createBrowserRouter([
  // 🔓 ROTTA PUBBLICA (NO Layout)
  {
    path: "/login",
    element: <Login />,
  },

  // 🔐 ROTTE PROTETTE
  {
    element: <Layout />,
    children: [
      { path: "/", element: <Home /> },
      { path: "/devices", element: <Devices /> },
      { path: "/automations", element: <Automations /> },
      { path: "/settings", element: <Settings /> },
    ],
  },
]);
