import { create } from "zustand";
import { apiCall } from "@/lib/api";

/* =========================
   TYPES
========================= */

export type User = {
  id: string;
  name: string;
  email: string;
};

type AuthState = {
  user: User | null;
  loading: boolean;
  error: string | null;

  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
};

/* =========================
   STORE
========================= */

export const useAuthStore = create<AuthState>((set) => ({
  // 🔐 carica sessione persistente
  user: JSON.parse(localStorage.getItem("user") || "null"),
  loading: false,
  error: null,

  /* ---------- LOGIN ---------- */
  login: async (email, password) => {
    set({ loading: true, error: null });

    try {
      // 👉 IDENTICO A POSTMAN
      const data = await apiCall("login", {
        email,
        password,
      });

      if (!data.success) {
        set({
          error: data.message || "Email o password non validi",
          loading: false,
        });
        return false;
      }

      // ✅ salva sessione
      localStorage.setItem("user", JSON.stringify(data.user));
      set({ user: data.user, loading: false });
      return true;
    } catch (err) {
      console.error("LOGIN ERROR", err);
      set({
        error: "Errore di rete",
        loading: false,
      });
      return false;
    }
  },

  /* ---------- LOGOUT ---------- */
  logout: () => {
    localStorage.removeItem("user");
    set({ user: null });
  },
}));
