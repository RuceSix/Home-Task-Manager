import { create } from "zustand";
import { API_URL } from "@/lib/api";

/* =========================
   TYPES
========================= */

export type Device = {
  id: string;
  name: string;
  room: string;
  status: boolean;
};

export type Automation = {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
};

type HomeState = {
  houseId: string | null;

  devices: Device[];
  automations: Automation[];
  loading: boolean;
  error: string | null;

  setHouseId: (houseId: string) => void;

  loadData: () => Promise<void>;

  addDevice: (name: string, room: string) => Promise<void>;
  toggleDevice: (deviceId: string, status: boolean) => Promise<void>;

  addAutomation: (name: string, description: string) => Promise<void>;
  toggleAutomation: (automationId: string, enabled: boolean) => Promise<void>;
};

/* =========================
   STORE
========================= */

export const useHomeStore = create<HomeState>((set, get) => ({
  houseId: null,

  devices: [],
  automations: [],
  loading: false,
  error: null,

  /* ---------- HOUSE ---------- */
  setHouseId: (houseId) => {
    set({ houseId });
  },

  /* ---------- LOAD ALL ---------- */
  loadData: async () => {
    const houseId = get().houseId;
    if (!houseId) return;

    set({ loading: true, error: null });

    try {
      const [devicesRes, automationsRes] = await Promise.all([
        fetch(API_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            action: "getDevices",
            houseId,
          }),
        }),
        fetch(API_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            action: "getAutomations",
            houseId,
          }),
        }),
      ]);

      const devicesJson = await devicesRes.json();
      const automationsJson = await automationsRes.json();

      set({
        devices: devicesJson.devices || [],
        automations: automationsJson.automations || [],
        loading: false,
      });
    } catch (err) {
      console.error("loadData error", err);
      set({
        error: "Errore caricamento dati",
        loading: false,
      });
    }
  },

  /* ---------- DEVICES ---------- */
  addDevice: async (name, room) => {
    const houseId = get().houseId;
    if (!houseId) return;

    await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "addDevice",
        houseId,
        name,
        room,
      }),
    });

    await get().loadData();
  },

  toggleDevice: async (deviceId, status) => {
    await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "toggleDevice",
        deviceId,
        status,
      }),
    });

    await get().loadData();
  },

  /* ---------- AUTOMATIONS ---------- */
  addAutomation: async (name, description) => {
    const houseId = get().houseId;
    if (!houseId) return;

    await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "addAutomation",
        houseId,
        name,
        description,
      }),
    });

    await get().loadData();
  },

  toggleAutomation: async (automationId, enabled) => {
    await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "toggleAutomation",
        automationId,
        enabled,
      }),
    });

    await get().loadData();
  },
}));
