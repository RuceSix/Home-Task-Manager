const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwrkJlCLE06aRfz7EBYWsn8zAulhvvg4HWIAO5LCaOrRU7jutMxLHxHJ2EXyuGaYAcJ/exec";
const CORS_PROXY = "https://cors-anywhere.herokuapp.com/";

export const API_URL = import.meta.env.DEV 
  ? CORS_PROXY + GOOGLE_SCRIPT_URL 
  : "/api/proxy";

export async function apiCall(action: string, payload: any = {}) {
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(import.meta.env.DEV && { "X-Requested-With": "XMLHttpRequest" })
      },
      body: JSON.stringify({ action, ...payload }),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (error) {
    console.error('API Error:', error);
    return { success: false, message: 'Errore di connessione' };
  }
}
