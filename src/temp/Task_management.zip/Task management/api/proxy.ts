const GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbwrkJlCLE06aRfz7EBYWsn8zAulhvg4HWIA05LCaOrRU7jutMx/exec";

export default async function handler(req: any, res: any) {
  // 🔐 CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  try {
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      redirect: "follow",
      body: JSON.stringify(req.body),
    });

    const text = await response.text();

    // 🔴 Se Google risponde con HTML → errore chiaro
    if (text.trim().startsWith("<")) {
      return res.status(500).json({
        success: false,
        message: "Apps Script non ha restituito JSON",
        raw: text.slice(0, 200),
      });
    }

    // ✅ JSON valido
    return res.status(200).json(JSON.parse(text));
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      message: "Proxy error",
      error: err.toString(),
    });
  }
}
